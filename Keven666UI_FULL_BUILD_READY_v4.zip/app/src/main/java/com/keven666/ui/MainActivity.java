package com.keven666.ui;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.*;
import android.provider.Settings;
import android.widget.*;

public class MainActivity extends Activity {
    FrameLayout root;
    KevenView view;
    EditText keyInput;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,7,13));
        getWindow().setNavigationBarColor(Color.rgb(5,7,13));
        root = new FrameLayout(this);
        view = new KevenView(this);
        root.addView(view, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        showKeyInput();
    }

    void showKeyInput(){
        if(keyInput != null) root.removeView(keyInput);
        keyInput = new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setHint("Introduce tu clave de licencia");
        keyInput.setTextColor(Color.WHITE);
        keyInput.setHintTextColor(Color.rgb(125,132,150));
        keyInput.setTextSize(16);
        keyInput.setPadding(52,0,52,0);
        keyInput.setBackground(makeField());
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1,64);
        lp.leftMargin=48; lp.rightMargin=48; lp.topMargin=485;
        root.addView(keyInput, lp);
    }
    GradientDrawable makeField(){
        GradientDrawable g=new GradientDrawable();
        g.setColor(Color.rgb(12,16,27)); g.setCornerRadius(28); g.setStroke(2,Color.rgb(255,45,100));
        return g;
    }
    void hideKey(){
        if(keyInput!=null){
            ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(keyInput.getWindowToken(),0);
            root.removeView(keyInput); keyInput=null;
        }
    }
    void unlock(){
        if(keyInput!=null && "keven666".equals(keyInput.getText().toString().trim().toLowerCase())){
            hideKey(); view.unlocked=true; view.invalidate();
        } else if(keyInput!=null){
            keyInput.setError("Clave incorrecta. Usa keven666");
        }
    }

    class KevenView extends View {
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG), s=new Paint(Paint.ANTI_ALIAS_FLAG); RectF r=new RectF();
        float den; boolean unlocked=false, running=false, background=false, antiban=true; int screen=0, theme=0; String lang="ESPAÑOL";
        int white=Color.rgb(245,246,250), muted=Color.rgb(150,158,177), pink=Color.rgb(255,55,108), green=Color.rgb(55,225,160), cyan=Color.rgb(75,210,255);
        int[] themes={Color.rgb(7,9,17),Color.rgb(15,8,24),Color.rgb(5,15,20),Color.rgb(16,11,8),Color.rgb(8,12,24)};
        String[] themeNames={"NEON","CRIMSON","CYBER","EMBER","OCEAN"};
        KevenView(Context c){super(c);den=getResources().getDisplayMetrics().density;s.setStyle(Paint.Style.STROKE);}
        float d(float x){return x*den;}
        void text(Canvas c,String t,float x,float y,float z,int col,boolean bold){p.setStyle(Paint.Style.FILL);p.setColor(col);p.setTextSize(d(z));p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));c.drawText(t,d(x),d(y),p);}
        void rr(Canvas c,float a,float b,float q,float w,float rad,int col){p.setStyle(Paint.Style.FILL);p.setColor(col);r.set(d(a),d(b),d(q),d(w));c.drawRoundRect(r,d(rad),d(rad),p);}
        void ol(Canvas c,float a,float b,float q,float w,float rad,int col,float sw){s.setColor(col);s.setStrokeWidth(d(sw));r.set(d(a),d(b),d(q),d(w));c.drawRoundRect(r,d(rad),d(rad),s);}
        @Override protected void onDraw(Canvas c){super.onDraw(c);c.drawColor(themes[theme]);grid(c);if(!unlocked){drawLogin(c);return;}if(screen==1)drawCustomize(c);else if(screen==2)drawLanguage(c);else drawHome(c);}
        void grid(Canvas c){s.setStrokeWidth(d(1));s.setColor(Color.argb(30,100,110,150));for(int x=15;x<430;x+=55)c.drawLine(d(x),0,d(x),getHeight(),s);for(int y=20;y<1200;y+=55)c.drawLine(0,d(y),getWidth(),d(y),s);}
        void logo(Canvas c,float y){rr(c,28,y,82,y+54,17,Color.rgb(55,20,43));ol(c,28,y,82,y+54,17,pink,1);text(c,"R",43,y+39,30,white,true);p.setColor(green);c.drawCircle(d(75),d(y+9),d(4),p);text(c,"Keven666",95,y+28,18,white,true);rr(c,205,y+3,255,y+27,12,Color.rgb(55,22,42));text(c,"V1.1",217,y+20,10,pink,true);text(c,"NEON CORE",95,y+45,9,muted,true);rr(c,355,y,397,y+54,16,Color.rgb(16,21,33));text(c,"⚙",366,y+35,20,white,true);}
        void drawLogin(Canvas c){
            logo(c,26); text(c,"FAKE LAG V1.0",74,165,27,white,true); text(c,"🔥",280,165,28,white,true); text(c,"NEON ACCESS",145,192,10,pink,true);
            rr(c,20,220,410,760,30,Color.rgb(20,24,35));ol(c,20,220,410,760,30,Color.rgb(65,72,90),1);
            rr(c,42,250,205,286,18,Color.rgb(18,48,45));text(c,"●  HÉ SISTEMA LISTO",55,274,11,green,true);
            text(c,"ACCEDER PARA ACTIVARLO",42,328,20,white,true);text(c,"Introduce la clave de licencia para continuar",42,356,12,muted,false);
            text(c,"CLAVE DE LICENCIA",48,425,11,muted,true);rr(c,300,401,385,428,12,Color.rgb(45,39,27));text(c,"ENCRYPTED ACCESS",310,419,9,Color.rgb(255,190,80),true);
            text(c,"⚿",61,537,28,pink,true);text(c,"◉",350,537,18,muted,true);
            rr(c,48,575,382,633,26,pink);text(c,"ACTIVAR CON KEY",145,611,15,white,true);
            text(c,"Clave de demo: keven666",48,675,12,muted,false);text(c,"Acceso local • sin conexión externa",48,700,11,muted,false);
        }
        void drawHeader(Canvas c){logo(c,18);}
        void drawHome(Canvas c){
            drawHeader(c);text(c,"Keven CORE",30,105,20,white,true);rr(c,350,86,398,112,12,Color.rgb(55,24,42));text(c,"V1.1",364,104,10,pink,true);
            rr(c,20,122,410,405,30,Color.rgb(18,23,36));ol(c,20,122,410,405,30,Color.rgb(70,28,52),1);
            float cx=d(215),cy=d(245);for(int i=5;i>=0;i--){s.setStrokeWidth(d(3));s.setColor(Color.argb(25+i*18,255,45,100));c.drawCircle(cx,cy,d(52+i*7),s);}p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(60,255,35,100));c.drawCircle(cx,cy,d(36),p);p.setColor(pink);c.drawCircle(cx,cy,d(15),p);text(c,"✦",208,252,16,white,true);p.setColor(running?green:muted);c.drawCircle(d(34),d(370),d(5),p);text(c,running?"ACTIVE":"READY",50,375,13,running?green:muted,true);
            rr(c,20,425,410,560,28,Color.rgb(18,23,36));text(c,"SESSION",40,460,16,white,true);text(c,running?"ACTIVE":"STANDBY",326,460,11,running?green:muted,true);rr(c,40,482,390,540,25,running?Color.rgb(30,38,50):pink);text(c,running?"STOP":"START",182,519,15,white,true);
            rr(c,20,580,410,700,25,Color.rgb(18,23,36));drawToggle(c,40,604,"∞","BACKGROUND",background);drawToggle(c,40,658,"✓","ANTIBAN",antiban);
            text(c,"ACCESS",30,740,13,white,true);text(c,"2 / 3",355,740,12,muted,true);rr(c,20,760,410,930,25,Color.rgb(18,23,36));access(c,45,800,"Floating display",true);access(c,45,850,"VPN connection",true);access(c,45,900,"Notifications",false);
            rr(c,20,950,410,1018,25,Color.rgb(10,14,23));rr(c,25,956,202,1012,22,Color.rgb(55,20,40));text(c,"●",65,991,16,pink,true);text(c,"CENTER",92,991,11,white,true);text(c,"⚙",285,992,18,muted,true);text(c,"CUSTOMIZE",312,991,10,muted,true);
        }
        void drawToggle(Canvas c,float x,float y,String icon,String label,boolean on){rr(c,x,y,x+54,y+44,22,on?Color.rgb(55,31,48):Color.rgb(30,39,58));text(c,icon,x+18,y+29,17,on?pink:cyan,true);text(c,label,x+68,y+28,14,white,true);rr(c,335,y+2,392,y+40,20,on?pink:Color.rgb(38,49,72));p.setColor(white);c.drawCircle(d(on?372:353),d(y+21),d(14),p);}
        void access(Canvas c,float x,float y,String label,boolean ok){text(c,label,x+45,y+4,13,white,true);rr(c,338,y-25,392,y+28,12,ok?Color.rgb(20,55,52):Color.rgb(55,25,45));text(c,ok?"OK":"SET",351,y+7,10,ok?green:pink,true);}
        void drawCustomize(Canvas c){
            drawHeader(c);text(c,"CUSTOMIZE",30,105,24,white,true);text(c,"Themes & visual variants",30,132,12,muted,false);
            rr(c,20,155,410,520,28,Color.rgb(18,23,36));ol(c,20,155,410,520,28,Color.rgb(70,28,52),1);text(c,"THEME COLOR",42,200,18,white,true);text(c,"Choose a background style",42,226,12,muted,false);
            for(int i=0;i<5;i++){float x=35+(i%3)*123,y=250+(i/3)*105;int col=themes[i];rr(c,x,y,x+108,y+88,22,Color.rgb(22,28,42));ol(c,x,y,x+108,y+88,22,theme==i?pink:Color.rgb(55,63,80),theme==i?2:1);p.setColor(col);c.drawCircle(d(x+54),d(y+30),d(20),p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(2));p.setColor(pink);c.drawCircle(d(x+54),d(y+30),d(20),p);text(c,themeNames[i],x+25,y+67,11,white,true);}
            rr(c,20,545,410,850,28,Color.rgb(18,23,36));text(c,"FLOATING ICON",42,588,18,white,true);text(c,"Visual-only button style",42,614,12,muted,false);String[] icons={"✦","∞","◉","◌","⚡","◍","◎","◆"};String[] names={"Spark","Ghost","Core","Portal","Flash","Orbit","Wave","Diamond"};for(int i=0;i<8;i++){float x=35+(i%4)*92,y=645+(i/4)*88;rr(c,x,y,x+78,y+70,18,Color.rgb(22,28,42));text(c,icons[i],x+29,y+33,20,white,true);text(c,names[i],x+17,y+56,9,muted,true);}
            rr(c,20,885,410,940,22,Color.rgb(12,16,27));text(c,"← BACK TO CORE",160,919,12,white,true);
        }
        void openVpnSettings(){
            try {
                startActivity(new Intent(Settings.ACTION_VPN_SETTINGS));
            } catch (Exception ex) {
                startActivity(new Intent(Settings.ACTION_SETTINGS));
            }
        }
        void drawLanguage(Canvas c){drawHeader(c);text(c,"SELECT LANGUAGE",30,110,23,white,true);langCard(c,25,145,"ES","ESPAÑOL",lang.equals("ESPAÑOL"));langCard(c,215,145,"EN","ENGLISH",lang.equals("ENGLISH"));rr(c,25,330,405,385,22,Color.rgb(18,23,36));text(c,"← BACK TO CORE",160,365,12,white,true);}
        void langCard(Canvas c,float x,float y,String code,String title,boolean sel){rr(c,x,y,x+165,y+145,24,Color.rgb(18,23,36));ol(c,x,y,x+165,y+145,24,sel?pink:Color.rgb(70,78,96),sel?2:1);text(c,code,x+55,y+45,20,white,true);text(c,title,x+27,y+100,13,white,true);}
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX()/den,y=e.getY()/den;
            if(!unlocked){if(y>560&&y<655){unlock();}return true;}
            if(screen==0){if(y>470&&y<550){running=!running;invalidate();}else if(y>590&&y<650){background=!background;invalidate();}else if(y>650&&y<715){antiban=!antiban;invalidate();}else if(y>825&&y<885){openVpnSettings();}else if(y>940&&x>220){screen=1;invalidate();}}
            else if(screen==1){for(int i=0;i<5;i++){float tx=35+(i%3)*123,ty=250+(i/3)*105;if(x>=tx&&x<=tx+108&&y>=ty&&y<=ty+88){theme=i;invalidate();return true;}}if(y>875){screen=0;invalidate();}}
            else if(screen==2){if(y>140&&y<310&&x<200){lang="ESPAÑOL";screen=0;}else if(y>140&&y<310){lang="ENGLISH";screen=0;}else if(y>320){screen=0;}invalidate();}
            return true;
        }
    }
}
