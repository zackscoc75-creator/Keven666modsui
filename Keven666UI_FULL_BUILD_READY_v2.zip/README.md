# Keven666 UI — Android

Proyecto Android nativo preparado para subir directamente a GitHub y compilar automáticamente mediante **GitHub Actions**.

## Identidad
- Nombre de la app: **Keven666**
- Versión: **1.0**
- Icono incluido: `app/src/main/res/drawable/ic_launcher.xml`
- Min SDK: 23
- Target SDK: 35
- Java: 17
- Android Gradle Plugin: 8.6.1

## Interfaz
Dashboard estilo oscuro/neón:
- Keven CORE
- READY / ACTIVE
- START / STOP
- Background / Antiban
- Access
- Selector de idioma
- Navegación inferior

Las opciones Background/Antiban de esta demo son únicamente controles visuales. No implementan evasión de sistemas antitrampas ni modificación de juegos de terceros.

## Compilar desde GitHub
El repositorio incluye `.github/workflows/build-apk.yml`.

### Automático
Cada `push` a la rama `main` inicia la compilación.

### Manual
En GitHub:
1. Abre la pestaña **Actions**.
2. Selecciona **Build Android APK**.
3. Pulsa **Run workflow**.
4. Espera a que termine el trabajo.
5. En la ejecución completada, busca **Artifacts** y descarga `Keven666-debug-apk`.

El archivo generado es `app-debug.apk`.

## Compilación local
También puede abrirse en Android Studio y compilarse con:
`Build > Build APK(s)`

No se necesita una clave externa para la variante debug.
