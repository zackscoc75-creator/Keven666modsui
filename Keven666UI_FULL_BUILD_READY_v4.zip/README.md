# Keven666 UI v1.1

Android UI demo inspired by the supplied reference videos.

## Demo key
`keven666`

## Build
The repository workflow can unzip this project archive and run Gradle directly.

## Safety scope
The Background/Antiban controls are visual demo controls only. This project does not implement anti-cheat bypasses, game modification, or evasion functionality.
