package com.keven666.ui;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(8,10,18));
        getWindow().setNavigationBarColor(Color.rgb(8,10,18));
        setContentView(new KevenView(this));
    }
}

class KevenView extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    boolean running=false, background=false, antiban=true, notifications=false;
    int screen=0; // 0 home, 1 language, 2 customize
    String lang="ESPAÑOL";
    float den;
    RectF r=new RectF();

    int bg=Color.rgb(6,8,15), panel=Color.rgb(18,23,36), panel2=Color.rgb(12,16,27);
    int white=Color.rgb(245,245,250), muted=Color.rgb(155,162,180), pink=Color.rgb(255,55,108);
    int cyan=Color.rgb(75,210,255), green=Color.rgb(55,225,160);

    KevenView(Context c){ super(c); den=getResources().getDisplayMetrics().density; p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); stroke.setStyle(Paint.Style.STROKE); setFocusable(true); }

    float d(float x){return x*den;}
    void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){
        p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(d(size));
        p.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL)); c.drawText(s,d(x),d(y),p);
    }
    void round(Canvas c,float l,float t,float rr,float bb,float rad,int color){
        p.setStyle(Paint.Style.FILL); p.setColor(color); r.set(d(l),d(t),d(rr),d(bb)); c.drawRoundRect(r,d(rad),d(rad),p);
    }
    void outline(Canvas c,float l,float t,float rr,float bb,float rad,int color,float sw){
        stroke.setColor(color); stroke.setStrokeWidth(d(sw)); r.set(d(l),d(t),d(rr),d(bb)); c.drawRoundRect(r,d(rad),d(rad),stroke);
    }

    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        c.drawColor(bg);
        // subtle grid
        stroke.setStrokeWidth(d(1)); stroke.setColor(Color.argb(35,80,100,140));
        for(int x=20;x<getWidth()/den;x+=55)c.drawLine(d(x),d(0),d(x),getHeight(),stroke);
        for(int y=70;y<getHeight()/den;y+=55)c.drawLine(0,d(y),getWidth(),d(y),stroke);
        if(screen==1) drawLanguage(c); else drawHome(c);
    }

    void header(Canvas c){
        round(c,18,12,392,72,24,Color.rgb(11,14,24));
        outline(c,18,12,392,72,24,Color.rgb(45,51,70),1);
        round(c,29,22,79,62,15,Color.rgb(65,22,47));
        text(c,"R",44,52,28,white,true);
        text(c,"Keven666",91,40,18,white,true);
        round(c,174,25,220,48,12,Color.rgb(55,24,42));
        text(c,"V1.0",184,41,10,pink,true);
        text(c,"NEON CORE",91,57,9,muted,true);
        round(c,342,22,380,62,14,panel);
        text(c,"⚙",352,49,20,white,true);
    }

    void drawHome(Canvas c){
        header(c);
        text(c,"Keven CORE",30,105,20,white,true);
        round(c,340,88,382,112,12,Color.rgb(55,24,42));
        text(c,"V1",354,105,10,pink,true);

        round(c,20,120,390,415,30,panel);
        outline(c,20,120,390,415,30,Color.rgb(65,25,50),1);
        // Core orb
        float cx=d(205), cy=d(245);
        for(int i=4;i>=0;i--){
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(d(3));
            p.setColor(Color.argb(20+i*18,255,45,100));
            c.drawCircle(cx,cy,d(55+i*6),p);
        }
        p.setStyle(Paint.Style.FILL); p.setColor(Color.argb(55,255,35,100)); c.drawCircle(cx,cy,d(36),p);
        p.setColor(pink); c.drawCircle(cx,cy,d(15),p);
        text(c,"✦",198,252,16,white,true);
        text(c,running?"ACTIVE":"READY",48,375,13,running?green:muted,true);
        p.setColor(running?green:muted); c.drawCircle(d(31),d(370),d(5),p);

        round(c,20,435,390,565,28,panel);
        text(c,"SESSION",40,468,16,white,true);
        text(c,running?"ACTIVE":"STANDBY",320,468,11,running?green:muted,true);
        round(c,40,490,370,545,24,running?panel2:pink);
        text(c,running?"STOP":"START",177,525,15,white,true);

        round(c,20,585,390,700,25,panel);
        drawToggleRow(c,30,610,"BACKGROUND",background);
        drawToggleRow(c,30,662,"ANTIBAN",antiban);

        text(c,"ACCESS",30,742,13,white,true);
        text(c,"2 / 3",340,742,12,muted,true);
        round(c,20,765,390,890,25,panel);
        accessRow(c,35,800,"Floating display",true);
        accessRow(c,35,845,"VPN connection",true);
        accessRow(c,35,890,"Notifications",notifications);

        round(c,20,920,390,970,20,Color.rgb(15,19,30));
        p.setColor(running?green:pink); c.drawCircle(d(36),d(945),d(5),p);
        text(c,running?"Core started":"Core stopped",52,950,12,white,true);

        // bottom nav
        round(c,18,990,392,1060,26,Color.rgb(9,12,20));
        round(c,25,997,165,1053,22,Color.rgb(55,20,40));
        text(c,"●",76,1032,18,pink,true); text(c,"CENTER",98,1032,11,white,true);
        text(c,"⚙",270,1033,18,muted,true); text(c,"CUSTOMIZE",292,1032,10,muted,true);
    }

    void drawToggleRow(Canvas c,float x,float y,String label,boolean on){
        text(c,label,x+50,y+15,13,white,true);
        round(c,x,y,72+x,y+42,20,on?pink:Color.rgb(35,44,65));
        p.setColor(Color.WHITE); c.drawCircle(d(on?x+52:x+20),d(y+21),d(14),p);
    }
    void accessRow(Canvas c,float x,float y,String label,boolean ok){
        text(c,label,x+35,y+4,13,white,true);
        round(c,330,y-22,380,y+28,12,ok?Color.rgb(20,55,52):Color.rgb(55,25,45));
        text(c,ok?"OK":"SET",342,y+8,10,ok?green:pink,true);
    }

    void drawLanguage(Canvas c){
        text(c,"SELECT LANGUAGE",30,100,27,white,true);
        text(c,"Choose your language",30,128,13,pink,true);
        text(c,"The language will be used across the app",30,158,12,muted,false);
        langCard(c,25,195,"ES","ESPAÑOL","Español",lang.equals("ESPAÑOL"));
        langCard(c,202,195,"EN","ENGLISH","English",lang.equals("ENGLISH"));
        langCard(c,25,380,"ID","INDONESIA","Bahasa Indonesia",lang.equals("INDONESIA"));
        round(c,25,620,390,675,22,panel);
        text(c,"←  BACK TO CORE",145,654,12,white,true);
    }
    void langCard(Canvas c,float x,float y,String code,String title,String sub,boolean selected){
        round(c,x,y,x+165,y+155,25,panel);
        outline(c,x,y,x+165,y+155,25,selected?pink:Color.rgb(75,80,105),selected?2:1);
        round(c,x+18,y+18,x+72,y+72,16,Color.rgb(50,38,58));
        text(c,code,x+32,y+51,16,white,true);
        text(c,title,x+18,y+112,14,white,true);
        text(c,sub,x+18,y+137,10,muted,false);
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_UP) return true;
        float x=e.getX()/den,y=e.getY()/den;
        if(screen==0){
            if(y>480 && y<560){ running=!running; invalidate(); }
            else if(y>595 && y<660){ background=!background; invalidate(); }
            else if(y>660 && y<720){ antiban=!antiban; invalidate(); }
            else if(y>985 && x>210){ screen=2; invalidate(); }
            else if(y>985 && x<200){ screen=1; invalidate(); }
        } else if(screen==1){
            if(y>195&&y<350&&x<195){lang="ESPAÑOL";screen=0;}
            else if(y>195&&y<350){lang="ENGLISH";screen=0;}
            else if(y>380&&y<540&&x<195){lang="INDONESIA";screen=0;}
            else if(y>620){screen=0;}
            invalidate();
        } else {
            if(y>620){screen=0;invalidate();}
        }
        return true;
    }
}
